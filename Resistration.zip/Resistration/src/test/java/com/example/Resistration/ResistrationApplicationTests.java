package com.example.Resistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}

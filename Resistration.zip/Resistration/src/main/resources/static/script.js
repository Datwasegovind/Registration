window.onload = loadCountries;

function loadCountries() {
    fetch('/api/employees/countries') // API call to fetch countries
        .then(response => response.json())
        .then(data => {
            const countrySelect = document.getElementById('country');
            data.forEach(country => {
                countrySelect.innerHTML += `<option value="${country.countryId}">${country.countryName}</option>`;
            });
        })
        .catch(error => console.error('Error loading countries:', error));
}

function loadStates() {
    const countryId = document.getElementById('country').value;

    if (countryId) {
        fetch(`/api/employees/states/${countryId}`) // API call to fetch states based on country
            .then(response => response.json())
            .then(data => {
                const stateSelect = document.getElementById('state');
                stateSelect.innerHTML = '<option value="">Select State</option>'; // Reset states dropdown

                data.forEach(state => {
                    stateSelect.innerHTML += `<option value="${state.stateId}">${state.stateName}</option>`;
                });

                document.getElementById('city').innerHTML = '<option value="">Select City</option>'; // Reset cities dropdown
            })
            .catch(error => console.error('Error loading states:', error));
    }
}

function loadCities() {
    const stateId = document.getElementById('state').value;

    if (stateId) {
        fetch(`/api/employees/cities/${stateId}`) // API call to fetch cities based on state
            .then(response => response.json())
            .then(data => {
                const citySelect = document.getElementById('city');
                citySelect.innerHTML = '<option value="">Select City</option>'; // Reset cities dropdown

                data.forEach(city => {
                    citySelect.innerHTML += `<option value="${city.cityId}">${city.cityName}</option>`;
                });
            })
            .catch(error => console.error('Error loading cities:', error));
    }
}

function submitForm() {
    const employeeData = {
        name: document.getElementById('name').value,
        address: document.getElementById('address').value,
        phone: document.getElementById('phone').value,
        email: document.getElementById('email').value,
        country: { countryId: document.getElementById('country').value },
        state: { stateId: document.getElementById('state').value },
        city: { cityId: document.getElementById('city').value }
    };

    fetch('/api/employees/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(employeeData)
    })
        .then(response => {
            if (response.ok) {
                alert('Employee Registered Successfully!');
                document.getElementById('registrationForm').reset();
            } else {
                alert('Error while registering employee.');
            }
        })
        .catch(error => console.error('Error submitting form:', error));
}

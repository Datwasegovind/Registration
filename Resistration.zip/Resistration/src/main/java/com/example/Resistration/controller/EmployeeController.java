package com.example.Resistration.controller;

import com.example.Resistration.model.City;
import com.example.Resistration.model.Country;
import com.example.Resistration.model.Employee;
import com.example.Resistration.model.State;
import com.example.Resistration.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    @Autowired
    private EmployeeService service;

    @PostMapping("/register")
    public ResponseEntity<Employee> registerEmployee(@RequestBody Employee employee) {
        return ResponseEntity.ok(service.saveEmployee(employee));
    }

    @GetMapping("/countries")
    public ResponseEntity<List<Country>> getCountries() {
        return ResponseEntity.ok(service.getCountries());
    }

    @GetMapping("/states/{countryId}")
    public ResponseEntity<List<State>> getStates(@PathVariable Long countryId) {
        return ResponseEntity.ok(service.getStates(countryId));
    }

    @GetMapping("/cities/{stateId}")
    public ResponseEntity<List<City>> getCities(@PathVariable Long stateId) {
        return ResponseEntity.ok(service.getCities(stateId));
    }
}

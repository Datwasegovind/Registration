package com.example.Resistration.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "state")
@Data
public class State {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long stateId;

    private String stateName;

    @ManyToOne
    @JoinColumn(name = "country_id")
    private Country country;
}

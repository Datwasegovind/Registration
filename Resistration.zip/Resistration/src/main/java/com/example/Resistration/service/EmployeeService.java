package com.example.Resistration.service;

import com.example.Resistration.model.City;
import com.example.Resistration.model.Country;
import com.example.Resistration.model.Employee;
import com.example.Resistration.model.State;
import com.example.Resistration.repository.CityRepository;
import com.example.Resistration.repository.CountryRepository;
import com.example.Resistration.repository.EmployeeRepository;
import com.example.Resistration.repository.StateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    private EmployeeRepository employeeRepository;
    private CountryRepository countryRepository;
    private StateRepository stateRepository;
     private CityRepository cityRepository;

    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public List<Country> getCountries() {
        return countryRepository.findAll();
    }

    public List<State> getStates(Long countryId) {
        return stateRepository.findByCountry_CountryId(countryId);
    }

    public List<City> getCities(Long stateId) {
        return cityRepository.findByState_StateId(stateId);
    }
}

package com.example.Resistration.repository;

public interface EmployeeRepository {
}

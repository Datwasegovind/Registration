package com.example.Resistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResistrationApplication.class, args);
	}

}
